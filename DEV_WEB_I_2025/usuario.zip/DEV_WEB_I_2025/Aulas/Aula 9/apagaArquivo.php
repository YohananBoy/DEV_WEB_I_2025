<?php

if(file_exists("texto.txt")) {
    unlink("texto.txt");
}