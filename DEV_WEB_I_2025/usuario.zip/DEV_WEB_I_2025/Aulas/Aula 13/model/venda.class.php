<?php
    class Venda extends ClassePai {
        public $cliente;
        public $vendedor;//tipo Funcionario
        public $produtosVendidos;
        public $valorTotal;

        function montaLinhaDados()
        {
           //TODO...
        }
    }
?>